/*
Nestor Gomez
Carnegie Mellon University
Eng. Computation, 24-780-B
Prob Set 6
Due Mon. Oct. 26, 2020
*/
#pragma once

#include <vector>

#include "Node.h"
class ViewManager;

class Slider {
private:
		std::vector<Node> theGuides;
		std::vector<Node> theSpline;

		int splineSubdivisions = 20;
		double splineTension = 0.8;

		double minX, minY, maxX, maxY;  // useful for finding default origin and scale

public:
	void readFile(std::ifstream& inFile);

	double getDistanceFromXY(double x, double y);
	// gets the distance along the spline for a given coord.
	// figures out nearest point to the spline

	void getXYfromDistance(double distance, double& xCoord, double& yCoord);
	// gets coordinates given a distance along the spline

	double getSlopeAngle(double distance);
	// gets the slope of the spline at the given distance along the spline

	int getIndexFromDistance(double distance);
	// get the index of the guide point that is just before the distance given

	void insertNode(Node& newNode, int index);
	// new node becomes the index-th node (i.e., index = 0 inserts at head)

	Node* findNode(double x, double y, double distance, bool searchSpline = false);
	// given model coordinates x,y , function returns the first guide point (or spline point)
	// that is within given distance
	// returns nullptr if no node meets the criteria

	void draw(/*ViewManager& theManager, */int slideColor,
		int lineWidth, int nodeColor, bool showNodes);

	void getBounds(double& xMin, double& xMax, double& yMin, double& yMax) {
		xMin = minX; xMax = maxX; yMin = minY; yMax = maxY;
	}

	void writeFile(std::ostream& output);
	// writes all data in the model to the given stream 

	void clearAll();

	double getSplineLength();

	bool deleteNode(Node* badNode);
	// deletes the node whose memory address matches the given node pointer

	void recalcSpline();
	// creates a smooth spline that goes through the guide points
	// and stores the points in a vector, including distance from start
	// of curve. Also resets bounds

	void setSplineParams(int divisions, double tension) {
		splineSubdivisions = divisions;
		splineTension = tension;
	}

private:
	void segmentPoints(int segIndex);
	// develops cubic spline points

	int getIndexFromDistanceSpline(double distance);
	// get the index of the spline point that is just before the distance given

};