#include "fssimplewindow.h"
#include "ysglfontdata.h"
#include "Node.h"
#include "ViewManager.h"
#include "StringPlus.h"

using namespace std;

Node::Node(double xCoord, double yCoord, double dist)
{
	x = xCoord; y = yCoord;
	distance = dist;
}

void Node::draw(/*ViewManager& aManager, */int size, bool filled, bool showLabel)
{
	double halfSize = size * sqrt(2.);

	// account for filled or not
	if (filled)
		glBegin(GL_QUADS);
	else
		glBegin(GL_LINE_LOOP);

	// simple diamond (always appears same size on screen)
	double screenX=0, screenY=0;
//	aManager.getScreenCoords(x, y, screenX, screenY);

	glVertex2f(screenX - halfSize, screenY);
	glVertex2f(screenX, screenY + halfSize);
	glVertex2f(screenX + halfSize, screenY);
	glVertex2f(screenX, screenY - halfSize);

	glEnd();

	if (showLabel) { // show coords
		string coords = StringPlus::sigFig(x,3) + ", " + StringPlus::sigFig(y,3);
		glRasterPos2i(screenX + 2 * size, screenY + 2 * size + 10);
		YsGlDrawFontBitmap6x10(coords.c_str());
	}
}

ostream& operator<<(ostream& os, const Node& aNode)
{
	os << aNode.x << "\t" << aNode.y << "\t" ;
	os << aNode.distance;
	
	return os;
}
