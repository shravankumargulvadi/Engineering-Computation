// 24-780 Engineering Computation Assignment 9
// Shravan Kumar Gulvadi
// Andrew Id: sgulvadi
// Description: Simulate physics of boxes sliding over a wedge
// Date:11/23/2022

#include <iostream>
#include <string>
#include "fssimplewindow.h"
#include "yspng.h"
#include "ysglfontdata.h"
#include "StringPlus.h"
#include "DrawingUtilNG.h"
#include "Track2D.h"
#include "StringPlus.h"

#include "SlideBox.h"

#define PI 3.14159265

const double GRAVITY = 9.80665;  // this implies units are meters and seconds

SlideBox::SlideBox()
{
	// some default parameters for quick testing
	props["width"] = 2.;
	props["height"] = 1.5;
	props["mass"] = 3;   // actually does not affect calculations (cancels out)
	props["mu"] = 0.1;   // coeff of friction b/w box and track
	props["initDist"] = 0;  // at start of slide
	props["initVel"] = 0;   // starts from rest
	props["initAccel"] = 0; // no push

	theTrack = nullptr;
	reset(); //start at user defined location 

	


	

}

void SlideBox::loadFromConsole()
{
	using namespace std;

	cout << endl << "Enter parameters for adding a slide box to model:" << endl;
	props["width"] =	StringPlus::getDouble(cin, "                               Box width (m) >> ");
	props["height"] =	StringPlus::getDouble(cin, "                              Box height (m) >> ");
	props["initDist"] = StringPlus::getDouble(cin, "            Initial Position along track (m) >> ");
	reset();

	// add more stuff . . .
	

}

void SlideBox::move(double deltaT)
{
	if (theTrack != nullptr && theTrack->getLength() > 0) {
		// change distance, velocity, and acceleration according to equations of motion

		//solve free body diagram
		float currAngle = theTrack->getAngle(currDist);
		//acceleration =-friction+ acceleration due to gravity component in the direction of sliding
		// multiplied negative sign to match the convetion
		int fricDirect;
		if (currVel != 0)
		{
			fricDirect = -currVel/abs(currVel);

		}
		else
		{
			fricDirect = 0;
		}
			
		currAccel =-(fricDirect* props["mu"] * GRAVITY * cos(currAngle * PI / 180) + GRAVITY * sin(currAngle * PI / 180));
		currVel += currAccel * deltaT;
		currDist += currVel * deltaT;
		//cout << "accel= " << currAccel<<endl;
		//cout << "vel= " << currVel << endl;

		if (currDist >= theTrack->getLength())
		{// if the box is out of track reset
			reset();
		}

	}
}

void SlideBox::paint()
{
	// use transformations to paint the box at it's current position and angle
	//float currAngle = 17.3;
	float currAngle = theTrack->getAngle(currDist);

	//Point2D currPosition = { 30,20 };
	Point2D currPosition = theTrack->getCoords(currDist);



	float width = props["width"];
	float height = props["height"];

	YsRawPngDecoder pngTemp; 
	pngTemp.Decode("wood.png");
	GLuint textureId01;
	glGenTextures(1, &textureId01);
	glBindTexture(GL_TEXTURE_2D, textureId01);

	// set up parameters for the current texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexImage2D
	(GL_TEXTURE_2D,
		0, // Level of detail
		GL_RGBA, // the "A" in RGBA will include the transparency
		pngTemp.wid, 
		pngTemp.hei,
		0, // Border width, but not supported and needs to be 0.
		GL_RGBA,
		GL_UNSIGNED_BYTE,
		pngTemp.rgba);






	glTranslatef(currPosition.x, currPosition.y, 0.);
	glRotatef(currAngle, 0.0, 0.0, 1);

	DrawingUtilNG::drawRectangle(-width / 2.0, 0., width, height, true);

	//adding texture -
	// enable textures 
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_TEXTURE_2D);

	glColor4d(1.0, 1.0, 1.0, 1.0);
	
	// draw a quad with texture coords too
	glBegin(GL_QUADS);

	glTexCoord2d(0.0, 0.0);
	glVertex2f(-width / 2, height);
	
	glTexCoord2d(1.0, 0.0);
	glVertex2f(width / 2, height);

	glTexCoord2d(1.0, 1.0);
	glVertex2f(width / 2, 0.0);

	glTexCoord2d(0.0, 1.0);
	glVertex2f(-width / 2, 0.0);

	glEnd();
	glDisable(GL_TEXTURE_2D);

	//disable textures 

	glRotatef(-currAngle, 0.0, 0.0, 1);
	glTranslatef(-currPosition.x, -currPosition.y, 0.);
}

std::ostream& operator<<(std::ostream& os, const SlideBox& aBox)
{
	auto oldPrecision = os.precision();
	os.precision(3);

	std::string spacer;
	if (&os == &std::cout) 
		spacer = ", "; // if outputting to console, use commas and keep on same line
	else
		spacer = "\n"; // if outputting to file, put each property on separate line
	
	// print properties in prescribed order
	std::vector<std::string> printOrder =
	{ "width", "height", "mu", "mass", "initDist", "initVel", "initAccel" };

	for (int i = 0; i < aBox.props.size(); i++) {
		if (aBox.props.find(printOrder[i]) != aBox.props.end()) { // if property is in map

			if (i > 0) os << spacer;
			os << printOrder[i] << "=" << aBox.props.at(printOrder[i]);// [] doesn't work here
		}
	}

	// print properties in alphabetical order (directly from map)
	//for (auto& item : aBox.props) {
	//  if (i>0) os << spacer;
	//	os << item.first << "=" << item.second;
	//}

	os.precision(oldPrecision);
	return os;
}
