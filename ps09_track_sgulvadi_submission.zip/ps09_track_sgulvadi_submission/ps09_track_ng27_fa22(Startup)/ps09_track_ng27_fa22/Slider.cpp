#include <vector>
#include <algorithm>
#include <math.h>
#include <iostream>
#include <sstream>

#include "Slider.h"
#include "fssimplewindow.h"
#include "Node.h"
#include "DrawingUtilNG.h"
#include "ViewManager.h"
#include "ysglfontdata.h"

using namespace std;

void Slider::readFile(ifstream& inFile)
{
	string currLine;
	stringstream currStream;
	double xCoord, yCoord, dist;

	while (!inFile.eof()) {
		getline(inFile, currLine);
		if (currLine != "") {
			currStream.str(currLine);
			currStream >> xCoord >> yCoord;  // don't care about  >> dist;
			currStream.clear();

			Node newNode(xCoord, yCoord, -1);

			theGuides.push_back(newNode); // add copy of the node to model
		}
	}

	// reset smooth curve
	recalcSpline();
}

double Slider::getDistanceFromXY(double x, double y)
{
	return 0.0;
}

void Slider::getXYfromDistance(double distance, double& xCoord, double& yCoord)
{ // needed?
	int index = getIndexFromDistanceSpline(distance);
	if (index != -1) {
		double currX = theSpline[index].getX();
		double currY = theSpline[index].getY();
		double currD = theSpline[index].getDistance();
		double nextX = theSpline[index + 1].getX();
		double nextY = theSpline[index + 1].getY();
		double nextD = theSpline[index + 1].getDistance();
		double ratio = (distance - currD) / (nextD - currD);

		xCoord = currX + ratio * (nextX - currX);
		yCoord = currY + ratio * (nextY - currY);
	}
	else {
		xCoord = -INFINITY;
		yCoord = -INFINITY;
	}
}

double Slider::getSlopeAngle(double distance)
{
	// find segment on spline that encompasses distance
	int index = 0;
	if (distance < 0)
		distance = 0;

	if (distance > theSpline.back().getDistance())
		index = theSpline.size() - 1;
	else {
		while (index < theSpline.size() && theSpline[index].getDistance() <= distance)
			index++;
	}

	// calculate angle of segment and convert to degrees
	double slope = atan2(theSpline[index].getY() - theSpline[index - 1].getY(),
		theSpline[index].getX() - theSpline[index - 1].getX()) * 45. / atan(1.);
	if (slope < 0)
		return slope + 360.;
	else
		return slope;
}

int Slider::getIndexFromDistance(double distance)
{
	if (0 <= distance && distance <= theGuides.back().getDistance())
		for (int i = 1; i < theGuides.size(); i++) {
			if (theGuides[i].getDistance() > distance)
				return i - 1;
		}

	return -1;
}

int Slider::getIndexFromDistanceSpline(double distance)
{
	if (0 <= distance && distance <= theSpline.back().getDistance())
		for (int i = 1; i < theSpline.size(); i++) {
			if (theSpline[i].getDistance() > distance)
				return i - 1;
		}

	return -1;
}

void Slider::insertNode(Node& newNode, int index)
{
	if (index < 0)
		index = 0;
	else if (index >= theGuides.size())
		index = theGuides.size();

	theGuides.insert(theGuides.begin() + index + 1, newNode);
	recalcSpline();
}

Node* Slider::findNode(double x, double y, double distance, bool searchSpline)
{
	double minX = x - distance, maxX = x + distance;
	double minY = y - distance, maxY = y + distance;
	double currX, currY;

	vector<Node>* searchVector;
	if (searchSpline)
		searchVector = &theSpline;
	else
		searchVector = &theGuides;

	for (auto& currNode : *searchVector) {
		currX = currNode.getX();
		currY = currNode.getY();

		if (minX < currX && currX < maxX && minY < currY && currY < maxY)
			return &(currNode);
	}

	return nullptr;
}

void Slider::draw(/*ViewManager& theManager, */int slideColor, int lineWidth, int nodeColor, bool showNodes)
{
	if (theGuides.size() == 0) {
		glColor3f(1, 0, 0);
		glRasterPos2d(10, 40);
		YsGlDrawFontBitmap16x20("Model is empty.");
	}
	else {

		glLineWidth(lineWidth);
		double red, green, blue;
		DrawingUtilNG::hsv2rgb(slideColor, 1, 1, red, green, blue);
		glColor3d(red, green, blue);

		//glBegin(GL_LINE_STRIP);
		//for (auto& currNode : theSpline)
		//	theManager.screenVertex(currNode.getX(), currNode.getY());

		//glEnd();
		glLineWidth(1);

		// show guideNodes
		if (showNodes) {
			DrawingUtilNG::hsv2rgb(nodeColor, 1, 1, red, green, blue);
			glColor3d(red, green, blue);
			for (auto& currNode : theGuides) {
				currNode.draw(/*theManager, */lineWidth + 4, false);
			}
		}
	}
}

void Slider::writeFile(std::ostream& output)
{
	for (auto& currNode : theGuides)
		output << currNode << endl;
}

void Slider::clearAll()
{
	theGuides.clear();
	theSpline.clear();
}

double Slider::getSplineLength()
{
	if (theSpline.size() > 0)
		return theSpline.back().getDistance();
	else
		return -1;
}

bool Slider::deleteNode(Node* badNode)
{
	for (int i = 0; i < theGuides.size(); i++) {
		if (badNode == &theGuides[i]) {
			theGuides.erase(theGuides.begin() + i);
			recalcSpline();
			return true;
		}
	}
	return false;
}

void Slider::recalcSpline()
{
	theSpline.clear();
	minX = minY = 0;
	maxX = maxY = 10;
	double currDist;

	// now get the distances
	if (theGuides.size() > 2) {
		currDist = 0;
		theGuides[1].setDistance(0);
		minX = min(theGuides[0].getX(), theGuides[1].getX());
		minY = min(theGuides[0].getY(), theGuides[1].getY());
		maxX = max(theGuides[0].getX(), theGuides[1].getX());
		maxY = max(theGuides[0].getY(), theGuides[1].getY());

		for (int i = 2; i < theGuides.size(); i++) {
			currDist += DrawingUtilNG::getDistance(theGuides[i].getX(), theGuides[i].getY(),
				theGuides[i - 1].getX(), theGuides[i - 1].getY());
			theGuides[i].setDistance(currDist);

			// check boundary
			minX = min(minX, theGuides[i].getX());
			minY = min(minY, theGuides[i].getY());
			maxX = max(maxX, theGuides[i].getX());
			maxY = max(maxY, theGuides[i].getY());
		}

		if (theGuides.size() >= 4) {

			// first and last guide points are for sloping the first part of curve
			for (int i = 1; i < theGuides.size() - 2; i++) {
				// generate spline points
				segmentPoints(i);

			}

			// now get the distances
			double currDist = 0;
			theSpline[0].setDistance(0);
			for (int i = 1; i < theSpline.size(); i++) {
				currDist += DrawingUtilNG::getDistance(theSpline[i].getX(), theSpline[i].getY(),
					theSpline[i - 1].getX(), theSpline[i - 1].getY());
				theSpline[i].setDistance(currDist);
			}
		}
	}
}

void Slider::segmentPoints(int segIndex)
{
	float c = splineTension; // spline tension (0.0 means no spline at all)

	Node prev = theGuides[segIndex - 1];
	Node curr = theGuides[segIndex];
	Node next = theGuides[segIndex + 1];
	Node nextNext = theGuides[segIndex + 2];


	float xa = -c * prev.getX() + (2. - c) * curr.getX()
		+ (c - 2.) * next.getX() + c * nextNext.getX();
	float xb = 2. * c * prev.getX() + (c - 3.) * curr.getX()
		+ (3. - 2. * c) * next.getX() - c * nextNext.getX();
	float xc = -c * prev.getX() + c * next.getX();
	float xd = curr.getX();

	float ya = -c * prev.getY() + (2. - c) * curr.getY()
		+ (c - 2.) * next.getY() + c * nextNext.getY();
	float yb = 2. * c * prev.getY() + (c - 3.) * curr.getY()
		+ (3. - 2. * c) * next.getY() - c * nextNext.getY();
	float yc = -c * prev.getY() + c * next.getY();
	float yd = curr.getY();

	// add the spline points

	theSpline.push_back(curr);
	double t, x, y;
	for (int k = 1; k <= splineSubdivisions; k++) {
		t = float(k) / splineSubdivisions;  // parameter
		x = xa * t * t * t + xb * t * t + xc * t + xd;
		y = ya * t * t * t + yb * t * t + yc * t + yd;
		//Node newNode(x, y);
		theSpline.push_back(Node(x, y));
	}

}

